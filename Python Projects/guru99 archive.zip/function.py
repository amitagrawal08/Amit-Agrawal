def square(x):
    return x*x
print(square(4))

def multiply(x,y):
    print(x*y)
multiply(2,8)

def guru99(*args):
    print(args)
guru99(1,2,3,5)
