var1 = "Guru99!"
var2 = "Software Testing"
print ("var1[0]:",var1[0])
print ("var2[1:5]:",var2[1:5])

print (r"hello""/n")
print (R"hello""\n")

x = "Hello World!"
print(x[:6])
print(x[0:6] + "Guru99")

oldstring = 'I like Guru99'
newstring = oldstring.replace('like', 'love')
print(newstring.upper())

oldstring = 'I like Guru99'
newstring = oldstring.replace('like', 'love')
print(newstring)

string="python at guru99"
print(string.upper())

string="python at guru99"
print(string.capitalize())


print(":".join("Python"))

string="12345"
print("".join(reversed(string)))

word="guru99 career guru99"
print(word.split(' '))

word="guru99 career guru99"
print(word.split('r'))

x = "Guru99"
y=x.replace("Guru99","Python")
print(x)

print(y)
