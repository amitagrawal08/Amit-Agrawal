x = 4
y = 5
print(('x > y  is',x>y))

a = True
b = False
print(('a and b is',a and b))
print(('a or b is',a or b))
print(('not a is',not a))
